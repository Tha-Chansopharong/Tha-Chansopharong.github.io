<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class AboutController extends Controller
{
    function index()
    {
        return view('about');
    }

}
