<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CategoryModel;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    private $cateogryObj;
    public function __construct()
    {
        $this->cateogryObj = new CategoryModel();
    }

    public function index()
    {
        $cateogries = $this->cateogryObj->getCategories();
        return view("admin.category.index", ['categories' => $cateogries]);
    }

    public function delete($id)
    {
        $this->cateogryObj->deleteCategory($id);
        return redirect('/admin/category');
    }

    public function add()
    {
        return view('admin.category.add');
    }

    public function addAction(Request $request)
    {
        $txtTitle = $request->input('txtTitle');
        $txtRemark = $request->input('txtRemark');
        $this->cateogryObj->createCategory($txtTitle, $txtRemark);
        return redirect('/admin/category');
    }

    public function update($id)
    {
        $category = $this->cateogryObj->findCategoryById($id);
        return view('admin.category.edit', ['category' => $category]);
    }

    public function updateAction(Request $request)
    {
        $id = $request->input('hidID');
        $title = $request->input('txtTitle');
        $remark = $request->input('txtRemark');
        $this->cateogryObj->updateCategory($id, $title, $remark);
        return redirect('/admin/category');
    }
}
