<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\UserModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class LoginController extends Controller
{
    public function index()
    {
        return view("admin.login");
    }

    public function loginAction(Request $request)
    {
        $username = $request->input("txtUsername");
        $password = $request->input("txtPassword");
        $userModel = new UserModel();
        $password = md5($password);
        $loginUser = $userModel->getUserLogin($username, $password);
        if (!empty($loginUser)) {
            //set session
            session_start();
            $_SESSION["username"] = $loginUser->email;
            return redirect('/admin/dashboard');
        } else {
            return redirect('/admin/login')->with('message', 'Fail to login');
        }
    }
}
