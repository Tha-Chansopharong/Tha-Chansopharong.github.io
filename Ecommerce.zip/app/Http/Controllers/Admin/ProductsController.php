<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CategoryModel;
use App\Models\ProductsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class ProductsController extends Controller
{

    public function index()
    {
        session_start();
        if (empty($_SESSION['username'])) {
            return redirect('/admin/login');
        }

        $productModel = new ProductsModel();
        $products = $productModel->getProducts();
        return view("admin.products.index", ['products' => $products]);
    }

    public function add()
    {
        $categoryModel = new CategoryModel();
        $categories = $categoryModel->getCategories();
        return view('admin.products.add', ['categories' => $categories]);
    }

    public function addAction(Request $request)
    {
        $title = $request->input('txtTitle');
        $price = $request->input('txtPrice');
        $currency = $request->input('txtCurrency');
        $discount = $request->input('txtDiscount');
        $description = $request->input('txtDescription');
        $category = $request->input('txtCategory');
        //upload
        $file = $request->file('file');
        $fileName = time() . '_' . $file->getClientOriginalName();
        $file->move(public_path('uploads'), $fileName);
        //using Unlink to delete file from folder
        //unlink(public_path('uploads/1698072287_img4.png'));

        $data = [
            'title' => $title,
            'price' => $price,
            'description' => $description,
            'category_id' => $category,
            'discount' => $discount,
            'currency' => $currency,
            'image' => $fileName
        ];
        $productModel = new ProductsModel();
        $productModel->addProduct($data);
        return redirect('/admin/products');
    }

    public function delete($id, $img)
    {
        $productModel = new ProductsModel();
        $productModel->delete($id);
        @unlink(public_path('uploads/' . $img));
        return redirect('/admin/products');
    }

    public function edit($id)
    {
        $categoryModel = new CategoryModel();
        $categories = $categoryModel->getCategories();

        $productModel = new ProductsModel();
        $product = $productModel->findProductById($id);
        return view('admin.products.edit', ['product' => $product, 'categories' => $categories]);
    }

    public function updateAction(Request $request)
    {
        $id = $request->input('hiddenId');
        $title = $request->input('txtTitle');
        $price = $request->input('txtPrice');
        $currency = $request->input('txtCurrency');
        $discount = $request->input('txtDiscount');
        $desc = $request->input('txtDescription');
        $cat = $request->input('txtCategory');
        $data = [
            'title' => $title,
            'price' => $price,
            'currency' => $currency,
            'discount' => $discount,
            'description' => $desc,
            'category_id' => $cat
        ];
        //upload image
        if (!empty($file)) {
            $file = $request->file('file');
            $fileName = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads'), $fileName);
            $data['image'] = $fileName;
        }

        $productModel = new ProductsModel();

        $productModel->update($id, $data);
        return redirect('/admin/products');
    }
}
