<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CategoryModel;
use App\Models\UserModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{

    public function index()
    {
        session_start();
        if (empty($_SESSION['username'])) {
            return redirect('/admin/login');
        }

        $userModel = new UserModel();
        $user = $userModel->getUsers();
        return view("admin.user.index", ['user' => $user]);
    }

    public function add()
    {
        return view('admin.user.add');
    }

    public function addAction(Request $request)
    {
        $name = $request->input('txtName');
        $username = $request->input('txtEmail');
        $phone = $request->input('txtPhone');
        $city = $request->input('txtCity');
        //upload
        $file = $request->file('file');
        $fileName = time() . '_' . $file->getClientOriginalName();
        $file->move(public_path('uploads'), $fileName);
        //using Unlink to delete file from folder
        //unlink(public_path('uploads/1698072287_img4.png'));

        $data = [
            'name' => $name,
            'email' => $username,
            'phone' => $phone,
            'city' => $city,
            'image' => $fileName
        ];
        $userModel = new UserModel();
        $userModel->addUser($data);
        return redirect('/admin/user');
    }

    public function delete($id, $img)
    {
        $userModel = new UserModel();
        $userModel->delete($id);
        @unlink(public_path('uploads/' . $img));
        return redirect('/admin/user');
    }

    public function edit($id)
    {
        
        $userModel = new UserModel();
        $user = $userModel->findUserById($id);
        return view('admin.user.edit', ['user' => $user]);
    }

    public function updateAction(Request $request)
    {
        $id = $request->input('hiddenId');
        $name = $request->input('txtName');
        $username = $request->input('txtEmail');
        $phone = $request->input('txtPhone');
        $city = $request->input('txtCity');
        $data = [
            'name' => $name,
            'email' => $username,
            'phone' => $phone,
            'city' => $city
        ];
        //upload image
        if (!empty($file)) {
            $file = $request->file('file');
            $fileName = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('uploads'), $fileName);
            $data['image'] = $fileName;
        }

        $userModel = new UserModel();

        $userModel->update($id, $data);
        return redirect('/admin/user');
    }
}
