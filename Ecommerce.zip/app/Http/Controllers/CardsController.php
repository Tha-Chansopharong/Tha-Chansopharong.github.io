<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class CardsController extends Controller
{
    public function listCards()
    {
        return view('view_cards');
    }
}
