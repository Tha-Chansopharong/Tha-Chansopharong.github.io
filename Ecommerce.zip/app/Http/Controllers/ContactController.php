<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class ContactController extends Controller
{
    function index()
    {
        return view('contact');
    }

}
