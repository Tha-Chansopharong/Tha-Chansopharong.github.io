<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\CategoryModel;
use App\Models\ProductsModel;

class HomeController extends Controller
{
    function index()
    {
        $categoryModel = new CategoryModel();
        $categories = $categoryModel->getCategories();
        $productModel = new ProductsModel();
        $products = $productModel->getProducts();
        return view('index', [
            'categories' => $categories,
            'products' => $products,
            'cat_id' => 0
        ]);
    }
}
