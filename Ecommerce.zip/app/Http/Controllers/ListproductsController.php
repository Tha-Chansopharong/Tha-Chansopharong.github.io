<?php

    namespace App\Http\Controllers;
    use App\Models\ProductsModel;
    use App\Http\Controllers\Controller;


    class ListproductsController extends Controller{
        public function listproduct(){
            $productModel = new ProductsModel();
            $products = $productModel->getProducts();

            return view('listproduct',['products'=> $products]);
        }
    }
?>