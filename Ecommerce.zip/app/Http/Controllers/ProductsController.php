<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\ProductsModel;
use App\Models\CategoryModel;

class ProductsController extends Controller
{
    public function productDetail($id)
    {
        $productModel = new ProductsModel();
        $product = $productModel->findProductById($id);
        return view("product_details", ['product' => $product]);
    }

    public function productInCategory($cat_id)
    {
        $categoryModel = new CategoryModel();
        $categories = $categoryModel->getCategories();
        $productModel = new ProductsModel();
        $products = $productModel->getProductByCateId($cat_id);
        return view('product_category', [
            'categories' => $categories,
            'products' => $products,
            'cat_id' => $cat_id
        ]);
    }
    public function index(){
        return view("product");
    }
}
