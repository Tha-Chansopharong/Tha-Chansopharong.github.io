<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class SignupController extends Controller
{
    function index()
    {
        return view('sign_up');
    }

}