<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class UserloginController extends Controller
{
    function index()
    {
        return view('user_login');
    }

}