<?php
namespace App\Models;

use Illuminate\Support\Facades\DB;

class CategoryModel
{
    public function getCategories()
    {
        $categories = DB::table("tbl_category")->orderBy('id', 'desc')->get();
        return $categories;
    }

    public function deleteCategory($id)
    {
        return DB::table("tbl_category")->where("id", $id)->delete();
    }

    public function createCategory($title, $remark)
    {
        return DB::table("tbl_category")->insert([
            "title" => $title,
            "remark" => $remark
        ]);
    }

    public function findCategoryById($id)
    {
        return DB::table("tbl_category")->where("id", $id)->first();

    }

    public function updateCategory($id, $title, $remark)
    {
        $data = ['title' => $title, 'remark' => $remark];
        return DB::table("tbl_category")->where('id', $id)->update($data);
    }
}
