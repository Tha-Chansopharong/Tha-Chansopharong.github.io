<?php
namespace App\Models;

use Illuminate\Support\Facades\DB;

class ProductsModel
{
    public function getProducts()
    {
        return DB::table("tbl_product")
            ->join('tbl_category', 'tbl_product.category_id', '=', 'tbl_category.id')
            ->select('tbl_product.*', 'tbl_category.title as cat_title')
            ->orderBy('tbl_product.id', 'desc')->get();
    }

    public function getProductByCateId($cateId)
    {
        return DB::table("tbl_product")
            ->join('tbl_category', 'tbl_product.category_id', '=', 'tbl_category.id')
            ->select('tbl_product.*', 'tbl_category.title as cat_title')
            ->where('tbl_product.category_id', $cateId)
            ->orderBy('tbl_product.id', 'desc')->get();
    }

    public function addProduct($data)
    {
        return DB::table('tbl_product')->insert($data);
    }
    public function delete($id)
    {
        return DB::table('tbl_product')->where('id', $id)->delete();
    }

    public function findProductById($id)
    {
        return DB::table('tbl_product')->where('id', $id)->first();
    }

    public function update($id, $data)
    {
        return DB::table('tbl_product')->where('id', $id)->update($data);
    }
}
