<?php
namespace App\Models;

use Illuminate\Support\Facades\DB;

class UserModel
{
    function getUsers()
    {
        $users = DB::table('tbl_user')->get();
        return $users;
    }

    function getUserLogin($username, $password)
    {
        $user = DB::table('tbl_user')
            ->where('email', $username)
            ->where('password', $password)
            ->first();
        return $user;
    }
    
    public function addUser($data)
    {
        return DB::table('tbl_user')->insert($data);
    }
    public function delete($id)
    {
        return DB::table('tbl_user')->where('id', $id)->delete();
    }

    public function findUserById($id)
    {
        return DB::table('tbl_user')->where('id', $id)->first();
    }

    public function update($id, $data)
    {
        return DB::table('tbl_user')->where('id', $id)->update($data);
    }
    
}
