@extends('layouts.admin')
@section('pageTitle', 'User_management')
@section('content')
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/user/add_action" method="post"  enctype="multipart/form-data">
                @csrf
                <table>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="txtName" ></td>
                    </tr>
                    <tr>
                        <td>Image</td>
                        <td>
                            <input type="file" name="file" />
                        </td>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td><input type="email" name="txtEmail" ></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input type="number" name="txtPhone" ></td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td><input type="text" name="txtCity" ></td>
                    </tr>
                   
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Create" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
@endsection
