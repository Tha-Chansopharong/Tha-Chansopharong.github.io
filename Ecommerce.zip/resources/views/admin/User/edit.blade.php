@extends('layouts.admin')
@section('pageTitle', 'Edit User_management')
@section('content')
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/user/update_action" method="post"  enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="hiddenId" value="{{$user->id}}" />
                <table>
                    <tr>
                        <td>Image</td>
                        <td>
                            <input type="file" name="file" />
                            <img width="100" src="{{asset('uploads/'. $user->image)}}" />
                        </td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="txtName" value="{{ $user->name }}"></td>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td><input type="email" name="txtEmail" value="{{$user->email}}" ></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input type="number" name="txtPhone" value="{{$user->phone}}"></td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td>
                            <input type="text" name="txtCity" value="{{$user->city}}"/>
                        </td>
                    </tr>
                   
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Update" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
@endsection
