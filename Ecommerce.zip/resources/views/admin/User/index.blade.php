@extends('layouts.admin')
@section('pageTitle', 'User Management')
@section('content')
<div class="col-sm-10 right-class">
    <div class="top"></div>
    <div class="bottom" id="renderContent">
        <div style="float: right;">
            <a href="/admin/user/add" class="btn btn-primary"> Add </a>
        </div>

        <div>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Action</th>
                </tr>
                @foreach ($user as $user )
                <tr>
                    <td>{{$user->id}}</td>
                    <td><img width="100" src="{{asset('uploads/'. $user->image)}}" /></td>
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>{{$user->phone}}</td>
                    <td>{{$user->city}}</td>
                    <td>
                        <a href="/admin/user/edit/{{$user->id}}">Edit</a> |
                        <a href="/admin/user/delete/{{$user->id}}/{{$user->image}}">Delete</a>
                    </td>
                </tr>
            @endforeach
            </table>
        </div>
    </div>
</div>
@endsection
