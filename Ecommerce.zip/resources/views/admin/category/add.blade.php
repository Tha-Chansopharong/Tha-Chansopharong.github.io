@extends('layouts.admin')
@section('pageTitle', 'Add Category')
@section('content')
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/category/add_action" method="post"  enctype="multipart/form-data">
                @csrf
                <table>
                    <tr>
                        <td>Title</td>
                        <td><input type="text" name="txtTitle" ></td>
                    </tr>
                    <tr>
                        <td>Remark</td>
                        <td><input type="text" name="txtRemark" ></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Create" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
@endsection
