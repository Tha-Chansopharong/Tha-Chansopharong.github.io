@extends('layouts.admin')
@section('pageTitle', 'Edit Category')
@section('content')
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/category/update_action" method="post"  enctype="multipart/form-data">
                @csrf
                <input type="hidden" name="hidID" value="{{$category->id}}" />
                <table>
                    <tr>
                        <td>Title</td>
                        <td><input type="text" name="txtTitle" value="{{$category->title}}"></td>
                    </tr>
                    <tr>
                        <td>Remark</td>
                        <td><input type="text" name="txtRemark" value="{{$category->remark}}"></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Update" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
@endsection
