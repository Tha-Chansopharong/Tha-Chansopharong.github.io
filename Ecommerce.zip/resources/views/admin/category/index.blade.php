@extends('layouts.admin')
@section('pageTitle', 'Category Mangement')
@section('content')
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div style="float: right;">
            <a href="/admin/category/add" class="btn btn-primary"> Add </a>
        </div>

        <div>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Remark</th>
                    <th>Action</th>
                </tr>
                @foreach ($categories as $category )
                <tr>
                    <td>
                        {{$category->id}}
                    </td>
                    <td>
                        {{$category->title}}
                    </td>
                    <td>
                        {{$category->remark}}
                    </td>

                    <td>
                        <a href="/admin/category/edit/{{$category->id}}">Edit</a> |
                        <a
                            href="/admin/category/delete/{{$category->id}}">Delete</a>
                    </td>
                </tr>
                @endforeach

            </table>
        </div>
    </div>
</div>
@endsection
