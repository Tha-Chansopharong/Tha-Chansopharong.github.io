@extends('layouts.admin_login')
@section('pageTitle', 'Logout')
@section('content')
  <?php
      session_start();
        if (!empty($_SESSION['username'])) {
            unset($_SESSION['username']);
            header("Location: /admin/login");
            exit(); 
        }

  ?>
@endsection
