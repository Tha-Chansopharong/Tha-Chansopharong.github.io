@extends('layouts.admin')
@section('pageTitle', 'Product Management')
@section('content')
<div class="col-sm-10 right-class">
    <div class="top"></div>
    <div class="bottom" id="renderContent">
        <div style="float: right;">
            <a href="/admin/products/add" class="btn btn-primary"> Add </a>
        </div>

        <div>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Title</th>
                    <th>price</th>
                    <th>Currency</th>
                    <th>Discount</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            @foreach ($products as $product )
                <tr>
                    <td>{{$product->id}}</td>
                    <td><img width="100" src="{{asset('uploads/'. $product->image)}}" /></td>
                    <td>{{$product->title}}</td>
                    <td>{{$product->price}}</td>
                    <td>{{$product->currency}}</td>
                    <td>{{$product->discount}}%</td>
                    <td>{{$product->cat_title}}</td>
                    <td>{{$product->description}}</td>
                    <td>
                        <a href="/admin/products/edit/{{$product->id}}">Edit</a> |
                        <a href="/admin/products/delete/{{$product->id}}/{{$product->image}}">Delete</a>
                    </td>
                </tr>
            @endforeach
            </table>
        </div>
    </div>
</div>
@endsection
