
@extends('layouts.app')
@section('pageTitle', 'List_Product')
@section('content')

{{-- style css --}}
<style>
@import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap');
@import url('https://fonts.googleapis.com/css2?family=EB+Garamond&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Alice&display=swap');

</style>

{{-- style --}}
{{-- <link rel="stylesheet" href="{{asset('admin/bootstrap-5.3.1-dist/css/bootstrap.min.css')}}">
<script src="{{asset('admin/bootstrap-5.3.1-dist/js/bootstrap.min.js')}}"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" /> --}}
{{-- endstyle --}}

  <section style="background-color: #b7c3e1; font-size:20px;background-image: url('https://thumbs.dreamstime.com/z/summer-vacation-swimming-background-theme-water-sports-seashells-loose-sand-sunglasses-clothes-underwater-goggles-over-70771842.jpg?w=992'); background-repeat: no-repeat, repeat; background-position: center;background-size: cover;" class="section product">
    <div style="border-radius:7px;width:550px; border:1px solid white;background-color:white;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19); " class="container">

      <h2 style="font-family: 'Alice', serif; font-weight:500;color:black;padding-top:23px;" class="h2 section-title">Contact Us</h2>

      <div style="width: 500px; text-align:center; margin-left:20px;font-family: 'EB Garamond', serif;">
        <p>Use this text to share information about your brand with your customers. 
            Describe a product, share announcements, or welcome customers to your store.</p>
      </div>

     
        <!-- Pills navs -->

        <div class="content" style="margin-top: 70px;">
            <ul style="width:500px; margin:0px auto;gap:18px;" class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist" >
               <h2 style="padding:10px 24px 8px 40px;">Let's Talk FashionClothes!</h2>
              </ul>
              <!-- Pills navs -->
              
              <!-- Pills content -->
              <div class="tab-content " style="width:416px; margin:0px auto;">
                <div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
                  <form >
                    <!-- Email input -->
                    <div class="form-outline mb-4" >
                      <input style=" font-size:12px; padding:10px 24px 8px 10px; width:416px; height:36px;margin:0px 0px 24px;margin-top: 23px; " type="email" id="loginName" class="form-control" placeholder="Email or username" />
                      {{-- <label class="form-label" for="loginName"></label> --}}
                    </div>
              
                    <!-- Password input -->
                    <div class="form-outline mb-4">
                      <input type="password" id="loginPassword" class="form-control" style=" font-size:12px; padding:10px 24px 8px 10px; width:416px; height:36px;margin:0px 0px 24px; " placeholder="Password" />
                      {{-- <label class="form-label" for="loginPassword"></label> --}}
                    </div>

                    {{-- Message of User --}}
                    <div class="form-outline mb-4">
                      {{-- <textarea type="text" id="loginMessage" class="form-control" style=" font-size:12px; padding:10px 24px 8px 10px; width:416px; height:36px;margin:0px 0px 24px; " placeholder="Type your message here..." ></textarea> --}}
                      <textarea  style="font-size:12px; padding:10px 24px 8px 10px; width:416px;margin:0px 0px 9px;margin-top: 2px; " id="loginName" value="Let's Take Fashion Clothes" placeholder="Describe yourself here..." id="w3review" name="w3review" rows="4" cols="50">
                       
                        </textarea>
                      {{-- <label class="form-label" for="loginPassword"></label> --}}
                    </div>
                    
                    <!-- 2 column grid layout -->
                 
              
                    <!-- Submit button -->
                    <button type="submit" class="btn btn-primary btn-block mb-4" style="color: #FFFFF; font-size:12px; background-color:#3B71CA; padding:10px 24px 8px 191px; width:416px; height:36px;margin:0px 0px 24px;border:none;text-align:center; font-weight: 500;">Submit</button>
              
                    <!-- Register buttons -->
                    {{-- <div style="style=color: #4F4F4F; font-size:16px;margin:0px 0px 16px; display:flex;margin-left: 121px; gap: 10px;" class="text-center">
                      <p >Not a member?</p>
                      <span>  <a href="/sign-up">Register</a></span>
                    </div> --}}
                  </form>
                </div>
               
        </div>

    </div>
@endsection