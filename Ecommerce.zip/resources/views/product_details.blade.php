@extends('layouts.app')
@section('pageTitle', 'Home')
@section('content')
<style>

</style>
<section class="section hero">
    <div class="container">
    <h2 class="h1 hero-title">
        <img src="{{asset('uploads/' . $product->image)}}">
    </h2>
    <p class="hero-text">
        {{$product->price}} {{$product->currency}}
      </p>
      <h2 class="h1 hero-title">
        {{$product->title}}
      </h2>
      <h2 class="h1 hero-title">

      </h2>
      <p class="hero-text">
        {!! $product->description !!}
      </p>



    </div>
  </section>
@endsection
