@extends('layouts.app')
@section('pageTitle', 'List cards')
@section('content')
<div class="container">
    <h2 class="h1 hero-title">
        List Cards
    </h2>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;

}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
    <table class="table table-striped cust-table">
          <tr>
            <th>Product</th>
            <th>Unit Price</th>
            <th>Qty</th>
            <th>Sub Total</th>
          </tr>
          <tbody id="list_prod_carts"></tbody>
      </table>
      <button class="btn btn-primary" type="submit">Place Order</button>
      <br/>
</div>

<script>
    $(document).ready(function(){
        var productCarts = localStorage.getItem('my_product_carts');
        productCarts = JSON.parse(productCarts);
        prodcutList = '';
        grantTotal = 0;
        var tr = '';
        for (const product in productCarts) {
            productObj = productCarts[product];
            var currency = productObj.currency;
            var unitPrice = (productObj.price * productObj.qty);
            tr = '<tr>';
            tr += '<td>' + productObj.title + '</td>';
            tr += '<td>' + unitPrice + ' '+  currency + '</td>';
            tr += '<td>' + productObj.qty + '</td>';
            tr += '<td>' + unitPrice + ' ' + currency + '</td>';
            tr += '</tr>';
            if(currency === 'KHR') {
                grantTotal += (unitPrice/4000);
            } else {
                grantTotal += unitPrice;
            }

            prodcutList += tr;
        }
        grantTotal = Math.ceil(grantTotal * 100) / 100;
        //Grant Total
        tr = '<tr>';
            tr += '<td colspan="3" style="text-align: right;">Grant Total</td>';
            tr += '<td>' + grantTotal + ' USD </td>';
            tr += '<\tr>';
        prodcutList += tr;
        $('#list_prod_carts').html(prodcutList);

    });
</script>
@endsection
