<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/* Handle frontend*/
Route::get('/', 'App\Http\Controllers\HomeController@index');
Route::get('/aboutus', 'App\Http\Controllers\AboutController@index');
Route::get('/products/details/{id}', 'App\Http\Controllers\ProductsController@productDetail');
Route::get('/products/category/{cat_id}', 'App\Http\Controllers\ProductsController@productInCategory');
Route::get('/cards/list', 'App\Http\Controllers\CardsController@listCards');
Route::get('/contactus/login', 'App\Http\Controllers\ContactController@index');

Route::get('/list-product','App\Http\Controllers\ListproductsController@listproduct');
Route::get('/user_login','App\Http\Controllers\UserloginController@index');
Route::get('/sign-up','App\Http\Controllers\SignupController@index');

/* End Handle frontend*/

/* Handle Admin (backend)*/
Route::get('/admin/login', 'App\Http\Controllers\Admin\LoginController@index');
Route::post('/admin/login_action', 'App\Http\Controllers\Admin\LoginController@loginAction');
Route::get('/admin/dashboard', 'App\Http\Controllers\Admin\DashboardController@index');

Route::get('/admin/User/input', 'App\Http\Controllers\Admin\UserController@index');
Route::get('/admin/logout', 'App\Http\Controllers\Admin\LogoutController@index');



Route::get('/admin/category', 'App\Http\Controllers\Admin\CategoryController@index');
Route::get('/admin/category/delete/{id}', 'App\Http\Controllers\Admin\CategoryController@delete');
Route::get('/admin/category/add', 'App\Http\Controllers\Admin\CategoryController@add');
Route::post('/admin/category/add_action', 'App\Http\Controllers\Admin\CategoryController@addAction');
Route::get('/admin/category/edit/{id}', 'App\Http\Controllers\Admin\CategoryController@update');
Route::post('/admin/category/update_action', 'App\Http\Controllers\Admin\CategoryController@updateAction');

Route::get('/admin/products', 'App\Http\Controllers\Admin\ProductsController@index');
Route::get('/admin/products/add', 'App\Http\Controllers\Admin\ProductsController@add');
Route::post('/admin/products/add_action', 'App\Http\Controllers\Admin\ProductsController@addAction');
Route::get('/admin/products/delete/{id}/{img}', 'App\Http\Controllers\Admin\ProductsController@delete');
Route::get('/admin/products/edit/{id}', 'App\Http\Controllers\Admin\ProductsController@edit');
Route::post('/admin/products/update_action', 'App\Http\Controllers\Admin\ProductsController@updateAction');

Route::get('/admin/user', 'App\Http\Controllers\Admin\UserController@index');
Route::get('/admin/user/add', 'App\Http\Controllers\Admin\UserController@add');
Route::post('/admin/user/add_action', 'App\Http\Controllers\Admin\UserController@addAction');
Route::get('/admin/user/delete/{id}/{img}', 'App\Http\Controllers\Admin\UserController@delete');
Route::get('/admin/user/edit/{id}', 'App\Http\Controllers\Admin\UserController@edit');
Route::post('/admin/user/update_action', 'App\Http\Controllers\Admin\UserController@updateAction');

/* End Handle Admin (backend)*/
