
<?php $__env->startSection('pageTitle', 'Contact Us'); ?>
<?php $__env->startSection('content'); ?>
    <h1>This is Our products</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/product.blade.php ENDPATH**/ ?>