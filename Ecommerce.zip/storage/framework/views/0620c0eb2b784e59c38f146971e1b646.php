<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('pageTitle'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('admin/bootstrap-5.3.1-dist/css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('admin/bootstrap-5.3.1-dist/js/bootstrap.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/styles.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>


<body>
    <div class="container-fluid">
        <div class="row bg-class">
            <div class="col-sm-2 left-class">
                <h5>RECORDS SYSTEM</h5>
                <p>
                    <a href="/admin/User/input">
                        <i class="fa-solid fa-user-gear"></i>
                        <span>USERS</span>
                    </a>
                </p>
                <p style="cursor: pointer;" id="btnProduct">
                    <a href="/admin/products">
                        <i class="fa-solid fa-user-gear"></i>
                        <span>Products</span>
                    </a>
                </p>
                <p>
                    <a href="/admin/category">
                        <i class="fa-solid fa-star-of-david"></i>
                        <span>Category</span>
                    </a>
                </p>
                <p>
                    <a href=" /admin/login">

                        <span>Logout</span>
                    </a>
                </p>

            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
<script src="<?php echo e(asset('admin/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
<script>
    window.onload = function() {
        CKEDITOR.replace('txtDescription');
    };
</script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/layouts/admin.blade.php ENDPATH**/ ?>