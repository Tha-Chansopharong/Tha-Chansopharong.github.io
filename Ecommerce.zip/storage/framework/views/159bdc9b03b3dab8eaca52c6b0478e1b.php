<?php $__env->startSection('pageTitle', 'User_management'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/user/add_action" method="post"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <table>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="txtName" ></td>
                    </tr>
                    <tr>
                        <td>Image</td>
                        <td>
                            <input type="file" name="file" />
                        </td>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td><input type="email" name="txtEmail" ></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input type="number" name="txtPhone" ></td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td><input type="text" name="txtCity" ></td>
                    </tr>
                   
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Create" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/admin/user/add.blade.php ENDPATH**/ ?>