
<?php $__env->startSection('pageTitle', 'List_Product'); ?>
<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('/css/sign_up.css')); ?>" rel="stylesheet"> 

<style>
  @import url('https://fonts.googleapis.com/css2?family=Roboto&display=swap');

</style>

<section class="vh-100 bg-image"
  style="background-image: url('https://thumbs.dreamstime.com/z/summer-vacation-swimming-background-theme-water-sports-seashells-loose-sand-sunglasses-clothes-underwater-goggles-over-70771842.jpg?w=992'); background-repeat: no-repeat, repeat; background-position: center;background-size: cover;">
  <div class="mask d-flex align-items-center h-100 gradient-custom-3">
    <div class="container h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-9 col-lg-7 col-xl-6">
          <div class="card" style="border-radius: 15px; width:496.8px; height:646.59px; margin-top: 40px; ">
            <div style="width:496.8px; height:646.59px; color:#4F4F4F; padding:48px; padding:5rem!important;" class="card-body p-5">
              <h2 style="color: 4F4F4F; font-size:28.66px;margin:0px 0px 48px;  width:400.8px; height:34.39px;font-family: 'Roboto', sans-serif;" class="text-uppercase text-center mb-5">Create an account</h2>

              <form>

                <div class="form-outline mb-4">
                  <input style="padding: 5.12px 12px; width:400.8px; height:44.63px; font-size:14px;" type="text" id="form3Example1cg" class="form-control form-control-lg" placeholder="Your Name" />
                  
                </div>

                <div class="form-outline mb-4">
                  <input style="padding: 5.12px 12px; width:400.8px; height:44.63px; font-size:14px;" type="email" id="form3Example3cg" class="form-control form-control-lg" placeholder="Your Email"/>
                  
                </div>

                <div class="form-outline mb-4">
                  <input style="padding: 5.12px 12px; width:400.8px; height:44.63px; font-size:14px;" type="password" id="form3Example4cg" class="form-control form-control-lg" placeholder="Password" />
                  
                </div>

                <div class="form-outline mb-4">
                  <input style="padding: 5.12px 12px; width:400.8px; height:44.63px; font-size:14px;" type="password" id="form3Example4cdg" class="form-control form-control-lg" placeholder="Repeat your password" />
                  
                </div>

                <div  style="color: #4F4F4F; font-size:16px;padding:9px 2px 0px 2.4px 30px; margin-left:56px;font-family: 'Roboto', sans-serif; width:313.33px; height:25.6px; gap:2px;" class="form-check d-flex justify-content-center mb-5">
                  <input class="form-check-input me-2" type="checkbox" value="" id="form2Example3cg" />
                  <label class="form-check-label" for="form2Example3g">
                    I agree all statements in 
                  </label>
                  <a href="#!" class="text-body"><u>Terms of service</u></a>
                </div>

                <div class="d-flex justify-content-center">
                  <button style="color: white!important; font-size:14px; font-family: 'Roboto', sans-serif; padding:12px 27px 11px 164px; width:400.8px; height:45.4px; background-color:#198754!important;border:none; "  type="button"
                    class="btn btn-success btn-block btn-lg gradient-custom-4 text-body">Register</button>
                </div>
                <div style=" width:400.8px ; height:25.6px; display:flex;" >
                  <span><p style="color: #757575; font-size:16px; margin:48px 0px 0px -19px;font-family: 'Roboto', sans-serif; " class="text-center text-muted mt-5 mb-0">Have already an account? </span>
                  <span><a style="padding-left: 269px; margin-top: -24px;" href="/contactus/login" class="fw-bold text-body"><u>Login here</u></a></p></span>
                </div>
              </form>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/sign_up.blade.php ENDPATH**/ ?>