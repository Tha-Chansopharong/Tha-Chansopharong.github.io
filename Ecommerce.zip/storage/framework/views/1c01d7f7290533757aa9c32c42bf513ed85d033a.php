<?php $__env->startSection('pageTitle', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<section class="section hero" style="background-image: url('<?php echo e(asset("images/hero-banner.png")); ?>')">
    <div class="container">

      <h2 class="h1 hero-title">
        New Summer <strong>Shoes Collection</strong>
      </h2>

      <p class="hero-text">
        Competently expedite alternative benefits whereas leading-edge catalysts for change. Globally leverage
        existing an
        expanded array of leadership.
      </p>

      <button class="btn btn-primary">
        <span>Shop Now</span>

        <ion-icon name="arrow-forward-outline" aria-hidden="true" role="img" class="md hydrated"></ion-icon>
      </button>

    </div>
  </section>

  <section class="section product">
    <div class="container">

      <h2 class="h2 section-title">Bestsellers Products</h2>

      <ul class="filter-list">

        <a href="/">
            <button class="filter-btn  <?php echo e($cat_id==0 ? 'active': ''); ?>">All</button>
          </a>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="/products/category/<?php echo e($category->id); ?>">
                    <button class="filter-btn">
                        <?php echo e($category->title); ?>

                    </button>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <ul class="product-list">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="product-item">
            <div class="product-card" tabindex="0">
              <figure class="card-banner">
                <img src="<?php echo e(asset('uploads/' . $product->image)); ?>" width="312" height="350" loading="lazy"
                  alt="Running Sneaker Shoes" class="image-contain">

                <div class="card-badge">New</div>

                <ul class="card-action-list">

                  <li class="card-action-item">
                    <button
                     class="card-action-btn"
                     aria-labelledby="card-label-1"
                     data-title="<?php echo e($product->title); ?>"
                     data-price="<?php echo e($product->price); ?>"
                     data-currency="<?php echo e($product->currency); ?>"
                     >
                      <ion-icon
                      name="cart-outline"
                      role="img" class="md hydrated"
                      aria-label="cart outline"></ion-icon>
                    </button>

                    <div class="card-action-tooltip add-to-card" id="card-label-1">Add to Cart</div>
                  </li>

                  <li class="card-action-item">
                    <button class="card-action-btn" aria-labelledby="card-label-2">
                      <ion-icon name="heart-outline" role="img" class="md hydrated"
                        aria-label="heart outline"></ion-icon>
                    </button>

                    <div class="card-action-tooltip" id="card-label-2">Add to Whishlist</div>
                  </li>

                  <li class="card-action-item">
                    <button class="card-action-btn" aria-labelledby="card-label-3">
                        <a href="/products/details/<?php echo e($product->id); ?>">
                      <ion-icon name="eye-outline" role="img" class="md hydrated" aria-label="eye outline"></ion-icon>
                        </a>
                    </button>
                    <div class="card-action-tooltip" id="card-label-3">
                        Quick View
                    </div>
                  </li>

                  <li class="card-action-item">
                    <button class="card-action-btn" aria-labelledby="card-label-4">
                      <ion-icon name="repeat-outline" role="img" class="md hydrated"
                        aria-label="repeat outline"></ion-icon>
                    </button>

                    <div class="card-action-tooltip" id="card-label-4">Compare</div>
                  </li>

                </ul>
              </figure>

              <div class="card-content">

                <div class="card-cat">
                  <a href="#" class="card-cat-link">
                    <?php echo e($product->cat_title); ?>

                  </a>
                </div>

                <h3 class="h3 card-title">
                  <a href="#"><?php echo e($product->title); ?></a>
                </h3>

                <data class="card-price" value="180.85"><?php echo e($product->price); ?> <?php echo e($product->currency); ?></data>

              </div>

            </div>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </ul>

    </div>
  </section>

  <script>
    $(document).ready(function() {
        $lists = [];
        $('.card-action-btn').click(function() {
            //get product title, price, currency
            $price = $(this).attr('data-price');
            $title = $(this).attr('data-title');
            $currency = $(this).attr('data-currency');
            $productJson = {
                'title': $title,
                'price': $price,
                'currency': $currency,
                'qty': 1
            };


            const productCarts = localStorage.getItem('my_product_carts');
            if (productCarts !== null) {
            // The item exists.
                $lists = JSON.parse(productCarts);
                $lists.push($productJson);
            } else {
            // The item does not exist.
             $lists.push($productJson);
            }
            localStorage.setItem("my_product_carts", JSON.stringify($lists) );
            //set localstorage
        });
    });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecommerce\resources\views/index.blade.php ENDPATH**/ ?>