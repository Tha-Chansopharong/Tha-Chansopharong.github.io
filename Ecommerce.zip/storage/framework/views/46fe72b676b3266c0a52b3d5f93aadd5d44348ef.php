<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('pageTitle'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('admin/bootstrap-5.3.1-dist/css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('admin/bootstrap-5.3.1-dist/js/bootstrap.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/styles.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <?php echo $__env->yieldContent('content'); ?>
<script src="<?php echo e(asset('admin/js/jquery-3.7.1.min.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\week10\ecommerce\resources\views/layouts/admin_login.blade.php ENDPATH**/ ?>