<?php $__env->startSection('pageTitle', 'List_Product'); ?>
<?php $__env->startSection('content'); ?>


<style>
@import url('https://fonts.googleapis.com/css2?family=Libre+Baskerville&display=swap');
@import url('https://fonts.googleapis.com/css2?family=EB+Garamond&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Alice&display=swap');

</style>





  <section style=" font-size:20px;" class="section product">
    <div style="border-radius:7px;width:550px;height:150px; background-image:url('https://cdn.vectorstock.com/i/preview-1x/26/67/about-us-sign-over-cut-out-ribbon-confetti-vector-48282667.jpg'); background-repeat: no-repeat, repeat; background-position: center;background-size: cover;" class="container">
    </div>
      <div>
        <div><p style="margin-left: 50px;font-family: 'Alice', serif; font-weight:500;color:black;padding-top:23px; width: 550px;">At Fashion Clothes Store, we understand that fashion is not just about what you wear; it's a reflection of your personality, your mood, and your individuality. That's why we curate a carefully selected collection of clothing, designed to cater to a wide range of tastes and preferences. From classic and timeless to bold and cutting-edge, we have something for everyone.</p></div>
        <p style="margin-left: 967px;font-family: 'Alice', serif; font-weight:500;color:black;padding-top:23px; width: 550px;align:right;">Welcome to Fashion Clothes , your ultimate destination for trendy and stylish fashion! Our passion for fashion drives us to provide you with the latest in clothing and accessories, all while ensuring an unforgettable shopping experience. Let us take you on a journey through our virtual boutique, where you'll discover the perfect pieces to elevate your style.</p>
      </div>
    
      <p style="margin:auto;font-family: 'Alice', serif; font-weight:500;color:black;padding-top:23px; width: 550px;align:center;">Quality and style go hand in hand at our store. We source our clothing from some of the most reputable and innovative fashion brands, ensuring that each piece is made with attention to detail and craftsmanship. When you shop with us, you're not just buying clothes; you're investing in your confidence and self-expression.</p>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/about.blade.php ENDPATH**/ ?>