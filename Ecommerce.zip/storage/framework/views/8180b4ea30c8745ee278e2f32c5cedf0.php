<?php $__env->startSection('pageTitle', 'Category Mangement'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div style="float: right;">
            <a href="/admin/category/add" class="btn btn-primary"> Add </a>
        </div>

        <div>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Remark</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($category->id); ?>

                    </td>
                    <td>
                        <?php echo e($category->title); ?>

                    </td>
                    <td>
                        <?php echo e($category->remark); ?>

                    </td>

                    <td>
                        <a href="/admin/category/edit/<?php echo e($category->id); ?>">Edit</a> |
                        <a
                            href="/admin/category/delete/<?php echo e($category->id); ?>">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/admin/category/index.blade.php ENDPATH**/ ?>