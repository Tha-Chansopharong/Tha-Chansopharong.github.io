
<?php $__env->startSection('pageTitle', 'Logout'); ?>
<?php $__env->startSection('content'); ?>
  <?php
      session_start();
        if (!empty($_SESSION['username'])) {
            unset($_SESSION['username']);
            header("Location: /admin/login");
            exit(); 
        }

  ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/admin/logout.blade.php ENDPATH**/ ?>