<?php $__env->startSection('pageTitle', 'About Us'); ?>
<?php $__env->startSection('content'); ?>
    <h1>About Us</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\week10\ecommerce\resources\views/about.blade.php ENDPATH**/ ?>