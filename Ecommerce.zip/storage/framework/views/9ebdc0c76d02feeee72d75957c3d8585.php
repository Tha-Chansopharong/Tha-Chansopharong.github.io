
<?php $__env->startSection('pageTitle', 'List_Product'); ?>
<?php $__env->startSection('content'); ?>
<section class="section hero" style="background-image: url('<?php echo e(asset("images/colours-fashion-bnr-aug18-2.jpg")); ?>')">
    <div class="container">

      <h2 style="color:white;" class="h1 hero-title">
        New Summer <strong>Fashion_Store Collection</strong>
      </h2>

      <p class="hero-text">
        Competently expedite alternative benefits whereas leading-edge catalysts for change. Globally leverage
        existing an
        expanded array of leadership.
      </p>

      <button class="btn btn-primary">
        <span>Shop Now</span>

        <ion-icon name="arrow-forward-outline" aria-hidden="true" role="img" class="md hydrated"></ion-icon>
      </button>

    </div>
  </section>

  <section class="section product">
    <div class="container">

      <h2 class="h2 section-title">Bestsellers Products</h2>

      <ul class="filter-list">

      </ul>

      <ul class="product-list">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="product-item">
            <div class="product-card" tabindex="0">
              <figure class="card-banner">
                <img src="<?php echo e(asset('uploads/' . $product->image)); ?>" width="312" height="350" loading="lazy"
                  alt="Running Sneaker Shoes" class="image-contain">

                <div class="card-badge">New</div>

                <ul class="card-action-list">

                  <li class="card-action-item">
                    <button class="card-action-btn" aria-labelledby="card-label-1">
                      <ion-icon name="cart-outline" role="img" class="md hydrated" aria-label="cart outline"></ion-icon>
                    </button>

                    <div class="card-action-tooltip" id="card-label-1">Add to Cart</div>
                  </li>

                  <li class="card-action-item">
                    <button class="card-action-btn" aria-labelledby="card-label-2">
                      <ion-icon name="heart-outline" role="img" class="md hydrated"
                        aria-label="heart outline"></ion-icon>
                    </button>

                    <div class="card-action-tooltip" id="card-label-2">Add to Whishlist</div>
                  </li>

                  <li class="card-action-item">
                    <button class="card-action-btn" aria-labelledby="card-label-3">
                        <a href="/products/details/<?php echo e($product->id); ?>">
                      <ion-icon name="eye-outline" role="img" class="md hydrated" aria-label="eye outline"></ion-icon>
                        </a>
                    </button>
                    <div class="card-action-tooltip" id="card-label-3">
                        Quick View
                    </div>
                  </li>

                  <li class="card-action-item">
                    <button class="card-action-btn" aria-labelledby="card-label-4">
                      <ion-icon name="repeat-outline" role="img" class="md hydrated"
                        aria-label="repeat outline"></ion-icon>
                    </button>

                    <div class="card-action-tooltip" id="card-label-4">Compare</div>
                  </li>

                </ul>
              </figure>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/listproduct.blade.php ENDPATH**/ ?>