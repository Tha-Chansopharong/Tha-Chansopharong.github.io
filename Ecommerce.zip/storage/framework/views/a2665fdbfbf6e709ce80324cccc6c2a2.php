<?php $__env->startSection('pageTitle', 'Edit Product'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/products/update_action" method="post"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="hiddenId" value="<?php echo e($product->id); ?>" />
                <table>
                    <tr>
                        <td>Title</td>
                        <td><input type="text" name="txtTitle" value="<?php echo e($product->title); ?>"></td>
                    </tr>
                    <tr>
                        <td>Price</td>
                        <td><input type="text" name="txtPrice" value="<?php echo e($product->price); ?>" ></td>
                    </tr>
                    <tr>
                        <td>Currency</td>
                        <td>
                            <select name="txtCurrency">
                                <option <?php echo e($product->currency == 'USD' ? 'selected': ''); ?> value="USD">USD</option>
                                <option <?php echo e($product->currency == 'KHR' ? 'selected': ''); ?> value="KHR">KHR</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Discount</td>
                        <td><input type="text" name="txtDiscount" value="<?php echo e($product->discount); ?>"> %</td>
                    </tr>
                    <tr>
                        <td>Description</td>
                        <td>
                            <textarea name="txtDescription" cols="50"><?php echo e($product->description); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td>Image</td>
                        <td>
                            <input type="file" name="file" />
                            <img width="100" src="<?php echo e(asset('uploads/'. $product->image)); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <td>Category</td>
                        <td>
                            <select name="txtCategory">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($product->category_id == $category->id ? 'selected': ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Update" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>