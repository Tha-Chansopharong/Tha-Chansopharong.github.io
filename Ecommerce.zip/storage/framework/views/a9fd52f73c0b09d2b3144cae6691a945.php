<?php $__env->startSection('pageTitle', 'Edit User_management'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-10 right-class">
    <div class="top">
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/user/update_action" method="post"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="hiddenId" value="<?php echo e($user->id); ?>" />
                <table>
                    <tr>
                        <td>Image</td>
                        <td>
                            <input type="file" name="file" />
                            <img width="100" src="<?php echo e(asset('uploads/'. $user->image)); ?>" />
                        </td>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td><input type="text" name="txtName" value="<?php echo e($user->name); ?>"></td>
                    </tr>
                    <tr>
                        <td>Username</td>
                        <td><input type="email" name="txtEmail" value="<?php echo e($user->email); ?>" ></td>
                    </tr>
                    <tr>
                        <td>Phone</td>
                        <td><input type="number" name="txtPhone" value="<?php echo e($user->phone); ?>"></td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td>
                            <input type="text" name="txtCity" value="<?php echo e($user->city); ?>"/>
                        </td>
                    </tr>
                   
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Update" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>