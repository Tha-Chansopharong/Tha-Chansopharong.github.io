<?php $__env->startSection('pageTitle', 'Add Category'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-10 right-class">
    <div class="top">
        <p style="cursor: pointer; color: #000;" id="btnLogout">
            <a href="login_action.php?action=logout">Logout</a>
        </p>
    </div>
    <div class="bottom" id="renderContent">
        <div>
            <form action="/admin/category/add_action" method="post"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <table>
                    <input type="file" name="file" id="file" />
                    <tr>
                        <td>Title</td>
                        <td><input type="text" name="txtTitle" ></td>
                    </tr>
                    <tr>
                        <td>Remark</td>
                        <td><input type="text" name="txtRemark" ></td>
                    </tr>
                    <tr>
                        <td><input type="submit" name="btnSubmit" value="Create" ></td>
                        <td></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\week10\ecommerce\resources\views/admin/category/add.blade.php ENDPATH**/ ?>