<?php $__env->startSection('pageTitle', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-sm-10 right-class">
        <div class="bottom" id="renderContent">
            <div style="float: right;">
                <a data-bs-toggle="modal" data-bs-target="#addUser" class="btn btn-primary"> Add </a>
            </div>

            <div>
                <table>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>NAME</th>
                        <th>Username</th>
                        <th>Phone</th>
                        <th>City</th>
                        <th>Action</th>
                    </tr>
                        <tr>
                            <td>

                            </td>
                            <td>

                            </td>
                            <td>

                            </td>
                            <td>

                            </td>
                            <td>

                            </td>
                            <td>

                            </td>
                            <td>
                                <a href="#">Edit</a> |
                                <a
                                    href="#">Delete</a>
                            </td>
                        </tr>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecommerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>