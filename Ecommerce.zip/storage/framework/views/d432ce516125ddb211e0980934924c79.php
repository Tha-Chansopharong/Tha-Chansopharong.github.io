<?php $__env->startSection('pageTitle', 'Product Management'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-10 right-class">
    <div class="top"></div>
    <div class="bottom" id="renderContent">
        <div style="float: right;">
            <a href="/admin/products/add" class="btn btn-primary"> Add </a>
        </div>

        <div>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Title</th>
                    <th>price</th>
                    <th>Currency</th>
                    <th>Discount</th>
                    <th>Category</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->id); ?></td>
                    <td><img width="100" src="<?php echo e(asset('uploads/'. $product->image)); ?>" /></td>
                    <td><?php echo e($product->title); ?></td>
                    <td><?php echo e($product->price); ?></td>
                    <td><?php echo e($product->currency); ?></td>
                    <td><?php echo e($product->discount); ?>%</td>
                    <td><?php echo e($product->cat_title); ?></td>
                    <td><?php echo e($product->description); ?></td>
                    <td>
                        <a href="/admin/products/edit/<?php echo e($product->id); ?>">Edit</a> |
                        <a href="/admin/products/delete/<?php echo e($product->id); ?>/<?php echo e($product->image); ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/admin/products/index.blade.php ENDPATH**/ ?>