<?php $__env->startSection('pageTitle', 'Home'); ?>
<?php $__env->startSection('content'); ?>
<section class="section hero">
    <div class="container">
    <h2 class="h1 hero-title">
        <img src="<?php echo e(asset('uploads/' . $product->image)); ?>">
    </h2>
    <p class="hero-text">
        <?php echo e($product->price); ?> <?php echo e($product->currency); ?>

      </p>
      <h2 class="h1 hero-title">
        <?php echo e($product->title); ?>

      </h2>
      <h2 class="h1 hero-title">

      </h2>
      <p class="hero-text">
        <?php echo $product->description; ?>

      </p>



    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\ecommerce\resources\views/product_details.blade.php ENDPATH**/ ?>