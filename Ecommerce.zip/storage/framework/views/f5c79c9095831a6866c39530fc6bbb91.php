<?php $__env->startSection('pageTitle', 'User Management'); ?>
<?php $__env->startSection('content'); ?>
<div class="col-sm-10 right-class">
    <div class="top"></div>
    <div class="bottom" id="renderContent">
        <div style="float: right;">
            <a href="/admin/user/add" class="btn btn-primary"> Add </a>
        </div>

        <div>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Username</th>
                    <th>Phone</th>
                    <th>City</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><img width="100" src="<?php echo e(asset('uploads/'. $user->image)); ?>" /></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->city); ?></td>
                    <td>
                        <a href="/admin/user/edit/<?php echo e($user->id); ?>">Edit</a> |
                        <a href="/admin/user/delete/<?php echo e($user->id); ?>/<?php echo e($user->image); ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Final-Project\footcap\resources\views/admin/user/index.blade.php ENDPATH**/ ?>